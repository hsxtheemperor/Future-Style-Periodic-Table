'use client'

import { NUCLEOSYNTHESIS_LABEL, NUCLEOSYNTHESIS_COLOR, type NucleosynthesisOrigin } from '@/lib/types'

const ENTRIES = Object.entries(NUCLEOSYNTHESIS_LABEL) as [NucleosynthesisOrigin, string][]

export function NucleosynthesisLegend() {
  return (
    <div className="flex flex-wrap gap-x-4 gap-y-1.5">
      {ENTRIES.map(([key, label]) => (
        <div key={key} className="flex items-center gap-1.5">
          <span
            className="w-2.5 h-2.5 rounded-full flex-shrink-0"
            style={{ background: NUCLEOSYNTHESIS_COLOR[key] }}
          />
          <span className="text-[10px] text-white/45 whitespace-nowrap">{label}</span>
        </div>
      ))}
    </div>
  )
}
