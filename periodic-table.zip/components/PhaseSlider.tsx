'use client'

import { PHASE_COLOR, type PhaseAtTemp } from '@/lib/elements'

interface Props {
  temperature: number
  onChange: (t: number) => void
}

const PRESETS = [
  { label: '0 K', value: 0, note: 'Absolute Zero' },
  { label: '77 K', value: 77, note: 'Liquid N₂' },
  { label: '293 K', value: 293, note: 'Room Temp' },
  { label: '1000 K', value: 1000, note: 'Forge Heat' },
  { label: '3000 K', value: 3000, note: 'Arc Plasma' },
  { label: '6000 K', value: 6000, note: 'Solar Surface' },
]

const PHASES: { id: PhaseAtTemp; label: string }[] = [
  { id: 'solid',   label: 'Solid' },
  { id: 'liquid',  label: 'Liquid' },
  { id: 'gas',     label: 'Gas' },
  { id: 'unknown', label: 'Unknown' },
]

export function PhaseSlider({ temperature, onChange }: Props) {
  return (
    <div className="flex flex-col gap-3 w-full">
      {/* Slider row */}
      <div className="flex items-center gap-3">
        <span className="text-[10px] font-mono text-white/30 w-6 text-right flex-shrink-0">0 K</span>
        <input
          type="range"
          min={0}
          max={6000}
          step={5}
          value={temperature}
          onChange={e => onChange(Number(e.target.value))}
          className="flex-1 phase-slider"
          aria-label="Temperature in Kelvin"
        />
        <span className="text-[10px] font-mono text-white/30 w-10 flex-shrink-0">6000 K</span>
        {/* Live readout */}
        <span
          className="text-[13px] font-mono font-semibold w-20 text-right flex-shrink-0"
          style={{ color: '#00d4ff' }}
        >
          {temperature.toLocaleString()} K
        </span>
      </div>

      {/* Preset buttons */}
      <div className="flex flex-wrap gap-1.5">
        {PRESETS.map(p => (
          <button
            key={p.value}
            onClick={() => onChange(p.value)}
            className="text-[10px] font-mono px-2.5 py-1 rounded-md transition-all duration-150"
            style={
              temperature === p.value
                ? { background: '#00d4ff', color: '#030509', fontWeight: 700 }
                : { background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.4)', border: '1px solid rgba(255,255,255,0.08)' }
            }
            title={p.note}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-3">
        {PHASES.map(ph => (
          <div key={ph.id} className="flex items-center gap-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full flex-shrink-0"
              style={{ background: PHASE_COLOR[ph.id] }}
            />
            <span className="text-[10px] text-white/40">{ph.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
