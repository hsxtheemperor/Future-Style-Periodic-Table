'use client'

import { memo, useMemo } from 'react'
import type { Element, VisualizationMode } from '@/lib/types'
import {
  getCategoryColor,
  getHeatmapValue,
  heatmapColor,
  nucleosynthesisColor,
  phaseAtTemperature,
  PHASE_COLOR,
  formatValue,
} from '@/lib/elements'

interface Props {
  element: Element
  mode: VisualizationMode
  heatmapMin: number
  heatmapMax: number
  activeCategoryId: string | null
  searchQuery: string
  onSelect: (el: Element) => void
  style?: React.CSSProperties
  /** Temperature in Kelvin — used only for phase-state mode */
  phaseTemperature?: number
}

function matchesSearch(el: Element, q: string): boolean {
  if (!q) return false
  const lq = q.toLowerCase().trim()
  return (
    el.name_en.toLowerCase().includes(lq) ||
    el.symbol.toLowerCase().includes(lq) ||
    String(el.number).includes(lq) ||
    el.category_en.toLowerCase().includes(lq) ||
    !!(el.block && el.block.toLowerCase().includes(lq))
  )
}

export const ElementCard = memo(function ElementCard({
  element,
  mode,
  heatmapMin,
  heatmapMax,
  activeCategoryId,
  searchQuery,
  onSelect,
  style,
  phaseTemperature = 293,
}: Props) {
  const isOverlay = mode === 'nucleosynthesis' || mode === 'phase-state'
  const isHeatmap = mode !== 'standard' && !isOverlay

  // Resolve the card accent colour for this mode
  const bgColor = useMemo(() => {
    if (mode === 'nucleosynthesis') {
      return nucleosynthesisColor(element.number)
    }
    if (mode === 'phase-state') {
      const phase = phaseAtTemperature(element, phaseTemperature)
      return PHASE_COLOR[phase]
    }
    if (isHeatmap) {
      const val = getHeatmapValue(element, mode)
      return heatmapColor(val, heatmapMin, heatmapMax)
    }
    return getCategoryColor(element.category_ui_name, element.color_hex)
  }, [mode, element, heatmapMin, heatmapMax, isHeatmap, phaseTemperature])

  // Heatmap numeric value (shown in corner)
  const heatVal = isHeatmap ? getHeatmapValue(element, mode) : null

  // Phase label for phase-state mode
  const phaseLabel = mode === 'phase-state'
    ? phaseAtTemperature(element, phaseTemperature)
    : null

  // Visibility
  const catMatch = activeCategoryId === null || element.category_ui_name === activeCategoryId
  const searchActive = searchQuery.trim().length > 0
  const searchMatch = searchActive ? matchesSearch(element, searchQuery) : false

  let opacity = 1
  if (activeCategoryId !== null && !catMatch) opacity = 0.1
  if (searchActive && !searchMatch) opacity = 0.08
  if (searchActive && searchMatch) opacity = 1
  if (activeCategoryId !== null && catMatch && !searchActive) opacity = 1

  const borderColor = searchMatch
    ? 'rgba(0,212,255,0.9)'
    : isHeatmap || isOverlay
      ? `${bgColor}55`
      : `${bgColor}50`

  // Background fill: overlay modes use a stronger fill
  const cardBg = isHeatmap || isOverlay ? `${bgColor}28` : `${bgColor}22`

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`${element.name_en}, atomic number ${element.number}`}
      onClick={() => onSelect(element)}
      onKeyDown={(e) => e.key === 'Enter' && onSelect(element)}
      className="element-card select-none"
      style={{
        ...style,
        opacity,
        backgroundColor: cardBg,
        borderColor,
        boxShadow: searchMatch ? '0 0 12px rgba(0,212,255,0.4)' : undefined,
        transition: 'background-color 0.35s ease, opacity 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease',
      }}
    >
      {/* Atomic number */}
      <span
        className="absolute top-[3px] left-[5px] text-[9px] font-mono leading-none"
        style={{ color: isHeatmap || isOverlay ? 'rgba(255,255,255,0.6)' : 'rgba(255,255,255,0.5)' }}
      >
        {element.number}
      </span>

      {/* Symbol */}
      <span
        className="text-[21px] font-semibold font-serif leading-none mt-[6px]"
        style={{
          color: isHeatmap || isOverlay ? bgColor : bgColor,
          textShadow: `0 0 12px ${bgColor}80`,
          letterSpacing: '-0.01em',
        }}
      >
        {element.symbol}
      </span>

      {/* Name */}
      <span
        className="text-[8.5px] font-normal mt-[1px] leading-none truncate w-full text-center px-0.5 font-serif"
        style={{ color: isHeatmap || isOverlay ? 'rgba(255,255,255,0.75)' : 'rgba(255,255,255,0.6)' }}
      >
        {element.name_en}
      </span>

      {/* Bottom-right info chip */}
      {isHeatmap && heatVal !== null && (
        <span className="absolute bottom-[2px] right-[3px] text-[8px] font-mono font-bold" style={{ color: bgColor }}>
          {formatValue(heatVal)}
        </span>
      )}

      {mode === 'phase-state' && phaseLabel && phaseLabel !== 'unknown' && (
        <span
          className="absolute bottom-[2px] right-[3px] text-[7.5px] font-mono font-semibold capitalize"
          style={{ color: bgColor }}
        >
          {phaseLabel}
        </span>
      )}

      {!isHeatmap && !isOverlay && (
        <span
          className="absolute bottom-[2px] right-[3px] text-[8px] font-mono"
          style={{ color: `${bgColor}90` }}
        >
          {element.atomic_mass.toPrecision(4)}
        </span>
      )}
    </div>
  )
})
