import type { Element } from './types'
import {
  CATEGORY_COLOR_MAP,
  CATEGORY_EN_MAP,
  NUCLEOSYNTHESIS_MAP,
  NUCLEOSYNTHESIS_COLOR,
} from './types'
import rawData from './elements.json'

const raw = rawData as { elements: Element[] }

export function getElements(): Element[] {
  return raw.elements
}

export function getCategoryColor(categoryUiName: string, colorHex?: string | null): string {
  if (colorHex) return colorHex
  return CATEGORY_COLOR_MAP[categoryUiName] || '#6b7280'
}

export function getCategoryNameEn(categoryUiName: string): string {
  return CATEGORY_EN_MAP[categoryUiName] || categoryUiName
}

export function getHeatmapValue(el: Element, mode: string): number | null {
  switch (mode) {
    case 'radius':   return el.radius
    case 'en':       return el.electronegativity_pauling
    case 'ip':       return el.ionization_energies?.[0] ?? null
    case 'melt':     return el.melt
    case 'boil':     return el.boil
    case 'density':  return el.density
    default:         return null
  }
}

export function getHeatmapRange(elements: Element[], mode: string): [number, number] {
  const vals = elements
    .map(e => getHeatmapValue(e, mode))
    .filter((v): v is number => v !== null && isFinite(v))
  if (vals.length === 0) return [0, 1]
  return [Math.min(...vals), Math.max(...vals)]
}

/**
 * Logarithmic heatmap colour — fixes the "outlier crush" problem where a few
 * extreme values (e.g. carbon boiling at 4300 K, tungsten at 5900 K) pull all
 * other elements into an indistinct muddy mid-tone.
 * Falls back to linear when min ≤ 0 (e.g. negative electron affinities).
 */
export function heatmapColor(value: number | null, min: number, max: number): string {
  if (value === null || value === undefined) return 'rgba(255,255,255,0.04)'

  let t: number
  const safeMin = Math.max(min, 1e-6)
  const safeMax = Math.max(max, safeMin + 1e-6)
  const safeVal = Math.max(value, 1e-6)

  if (min > 0) {
    // Log scale: dramatically better contrast across the range
    t = (Math.log(safeVal) - Math.log(safeMin)) / (Math.log(safeMax) - Math.log(safeMin))
  } else {
    // Linear fallback for properties that can be zero or negative
    t = (value - min) / (max - min || 1)
  }
  t = Math.max(0, Math.min(1, t))

  // Cyberpunk gradient: deep indigo → cyan → teal → lime → amber → red
  const stops: [number, number, number][] = [
    [30,  20, 100],   // indigo
    [0,  180, 220],   // cyan
    [20, 210, 150],   // teal-green
    [200,220,  20],   // lime
    [240, 80,  20],   // red-orange
  ]
  const seg = t * (stops.length - 1)
  const i   = Math.floor(seg)
  const frac = seg - i
  const a = stops[Math.min(i, stops.length - 1)]
  const b = stops[Math.min(i + 1, stops.length - 1)]
  const r  = Math.round(a[0] + (b[0] - a[0]) * frac)
  const g  = Math.round(a[1] + (b[1] - a[1]) * frac)
  const bl = Math.round(a[2] + (b[2] - a[2]) * frac)
  return `rgb(${r},${g},${bl})`
}

/** Returns the nucleosynthesis accent colour for an element. */
export function nucleosynthesisColor(atomicNumber: number): string {
  const origin = NUCLEOSYNTHESIS_MAP[atomicNumber] ?? 'unknown'
  return NUCLEOSYNTHESIS_COLOR[origin]
}

/**
 * Returns the phase of an element at a given temperature (K).
 * Uses melting/boiling points from the dataset.
 */
export type PhaseAtTemp = 'solid' | 'liquid' | 'gas' | 'unknown'

export function phaseAtTemperature(el: Element, tempK: number): PhaseAtTemp {
  if (el.melt === null && el.boil === null) return 'unknown'
  if (el.melt !== null && tempK < el.melt) return 'solid'
  if (el.boil !== null && tempK < el.boil) return 'liquid'
  if (el.boil !== null && tempK >= el.boil) return 'gas'
  if (el.melt !== null && tempK >= el.melt) return 'liquid'
  return 'unknown'
}

export const PHASE_COLOR: Record<PhaseAtTemp, string> = {
  solid:   '#60a5fa', // blue
  liquid:  '#34d399', // emerald
  gas:     '#f97316', // orange
  unknown: '#374151', // dark gray
}

export function formatValue(val: number | null | undefined, decimals = 3): string {
  if (val === null || val === undefined) return '—'
  if (!isFinite(val)) return '—'
  return Number(val.toPrecision(decimals)).toString()
}

/**
 * Effective nuclear charge via Slater's Rules (simplified).
 * Zeff = Z - S, where S is the shielding constant.
 */
export function calcZeff(el: Element): number {
  const { shells } = el
  if (!shells || shells.length === 0) return el.number
  // Build a flat electron sequence per shell group
  // Slater groups: [1s] [2s,2p] [3s,3p] [3d] [4s,4p] [4d] [4f] ...
  // Simplified: group shells as given, apply standard Slater shielding
  let S = 0
  const n = shells.length
  for (let i = 0; i < n - 1; i++) {
    // Every electron in a lower shell contributes 0.85 (adjacent) or 1.00 (deeper)
    S += shells[i] * (n - i - 1 === 1 ? 0.85 : 1.0)
  }
  // Electrons in the same (outermost) shell contribute 0.35 each (excluding the electron itself)
  S += (shells[n - 1] - 1) * 0.35
  return Math.max(1, el.number - S)
}
